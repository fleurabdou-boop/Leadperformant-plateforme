/* Atelier du leader : onglets accessibles et trois outils, calcul local. */
(function () {
  var tabs = Array.prototype.slice.call(document.querySelectorAll('[role="tab"]'));
  function sel(t) {
    tabs.forEach(function (x) {
      var on = x === t; x.setAttribute('aria-selected', on); x.tabIndex = on ? 0 : -1;
      document.getElementById(x.getAttribute('aria-controls')).hidden = !on;
    });
  }
  tabs.forEach(function (t, i) {
    t.addEventListener('click', function () { sel(t); });
    t.addEventListener('keydown', function (e) {
      var j = e.key === 'ArrowRight' ? i + 1 : e.key === 'ArrowLeft' ? i - 1 : null;
      if (j === null) return; j = (j + tabs.length) % tabs.length; sel(tabs[j]); tabs[j].focus(); e.preventDefault();
    });
  });
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function val(f, n) { return (f.elements[n].value || '').trim(); }

  var fv = document.querySelector('[data-tool="vision"]');
  if (fv) fv.addEventListener('submit', function (e) {
    e.preventDefault();
    var o = document.querySelector('[data-out="vision"]');
    var w = val(fv, 'who'), a = val(fv, 'amb'), v = val(fv, 'val'), h = val(fv, 'hor');
    if (!w && !a && !v && !h) { o.hidden = false; o.innerHTML = '<p>Renseignez au moins un des quatre champs.</p>'; return; }
    o.innerHTML = '« Pour <strong>' + esc(w || 'qui ?') + '</strong>, nous voulons <strong>' + esc(a || 'quelle ambition ?') + '</strong>, <strong>' + esc(v || 'par quelle valeur ?') + '</strong>, <strong>' + esc(h || 'à quel horizon ?') + '</strong>. »' +
      '<p>Relisez-la à voix haute : si elle ne tient pas en une respiration, raccourcissez-la.</p>';
    o.hidden = false;
  });

  var D = {
    'faible|faible': ['Diriger', "Donnez des consignes claires et un cadre serré. Vous décidez et vous expliquez le « comment »."],
    'faible|elevee': ['Entraîner', "La personne est motivée mais peu expérimentée : guidez de près, en expliquant le « pourquoi ». Formez, montrez, encouragez."],
    'elevee|faible': ['Épauler', "La personne est compétente mais a perdu de l'élan : écoutez, redonnez du sens, décidez ensemble et valorisez."],
    'elevee|elevee': ['Déléguer', "Confiez la responsabilité et le « comment ». Fixez le cap, laissez l'autonomie, restez disponible."]
  };
  var fd = document.querySelector('[data-tool="deleg"]');
  if (fd) {
    var upd = function () {
      var k = fd.querySelector('input[name="c"]:checked').value + '|' + fd.querySelector('input[name="m"]:checked').value;
      document.querySelector('[data-out="deleg"]').innerHTML = 'Posture recommandée : <strong>' + D[k][0] + '</strong><p>' + D[k][1] + '</p>';
    };
    fd.addEventListener('change', upd); upd();
  }

  var ff = document.querySelector('[data-tool="fb"]');
  if (ff) ff.addEventListener('submit', function (e) {
    e.preventDefault();
    var o = document.querySelector('[data-out="fb"]');
    var d = val(ff, 'd'), x = val(ff, 'e'), s = val(ff, 's'), k = val(ff, 'k');
    if (!d && !x && !s && !k) { o.hidden = false; o.innerHTML = '<p>Renseignez au moins une des quatre étapes.</p>'; return; }
    o.innerHTML = '« <strong>' + esc(d || 'les faits') + '</strong> ; <strong>' + esc(x || "l'impact") + '</strong>. <strong>' + esc(s || 'la demande') + '</strong> : <strong>' + esc(k || 'le bénéfice') + '</strong>. »';
    o.hidden = false;
  });
})();
