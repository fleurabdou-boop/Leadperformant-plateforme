/* Laboratoire de la parole — quatre espaces : évaluer, s'entraîner, préparer, suivre */
(function () {
  "use strict";
  var U = window.LPU, LP = window.LP || {};
  var $ = U.$, $$ = U.$$, esc = U.esc, store = U.store;
  var root = $("#lab"); if (!root) return;
  var ARROW = '<span class="arrow" aria-hidden="true">→</span>';
  var timers = [];
  function clearAll() { timers.forEach(function (t) { clearInterval(t); clearTimeout(t); cancelAnimationFrame(t); }); timers = []; stopMic(); }
  var hist = { all: function () { return store.get("hist", []); }, add: function (e) { var h = hist.all(); e.d = Date.now(); h.unshift(e); store.set("hist", h.slice(0, 80)); } };
  var fmt = function (s) { s = Math.max(0, Math.round(s)); return Math.floor(s / 60) + ":" + ("0" + s % 60).slice(-2); };
  var rnd = function (a) { return a[Math.floor(Math.random() * a.length)]; };

  /* ------------------------------------------------ Données */
  var SUJETS = ["Le silence est-il une forme de parole ?", "Ce que j'ai appris d'un échec", "Faut-il toujours dire la vérité à son équipe ?", "La meilleure décision que j'aie prise", "Convaincre ou persuader : quelle différence ?", "Ce qu'un leader ne délègue jamais", "Le courage de dire non", "Une personne qui a changé ma façon de voir", "Pourquoi l'écoute est une compétence de dirigeant", "Faut-il préparer une improvisation ?", "Le télétravail renforce-t-il la confiance ?", "Mon objet fétiche et ce qu'il dit de moi", "La ponctualité est-elle une politesse ?", "Ce que la jeunesse apprend aux anciens", "Peut-on réussir seul ?", "L'erreur est-elle une étape nécessaire ?", "Le plus beau métier du monde", "Faut-il se méfier de l'unanimité ?", "Une ville qui m'a marqué", "Ce que je dirais à mes vingt ans", "Le pouvoir des mots dans une négociation", "Faut-il tout dire pour être sincère ?", "La confiance se décrète-t-elle ?", "Un livre qui devrait être lu par tous", "Pourquoi les réunions échouent", "Le meilleur conseil que l'on m'ait donné", "Faut-il aimer son travail ?", "La politesse est-elle dépassée ?", "Ce que le sport enseigne au leader", "Défendre une idée impopulaire", "Le rôle de l'humour dans un discours", "Faut-il sortir de sa zone de confort ?", "Une tradition que je veux transmettre", "L'intelligence artificielle va-t-elle remplacer l'orateur ?", "Pourquoi la première impression compte", "Le jour où j'ai osé", "La lenteur est-elle une qualité ?", "Faut-il écouter ses critiques ?", "Ce qui fait un bon chef d'équipe", "La parole d'un enfant compte-t-elle autant ?", "Mon plus grand trac", "Faut-il préférer l'expérience au diplôme ?", "L'art de dire non avec élégance", "La mémoire d'un lieu", "Pourquoi raconter des histoires ?", "Le prix d'une promesse", "Faut-il toujours avoir un plan B ?", "La plus belle leçon de mes parents", "Ce que l'Afrique apporte au monde", "La simplicité est-elle la sophistication suprême ?", "Le rôle du griot aujourd'hui", "Une décision difficile que je ne regrette pas", "Faut-il avoir peur du conflit ?", "La qualité que j'admire le plus", "Comment donner envie d'écouter", "Le droit à l'erreur au travail", "Ce que je ferais avec une heure de plus par jour", "Être leader sans titre", "Le moment où tout a basculé", "Pourquoi je crois en l'éloquence"];
  var CONTRAINTES = ["Commencez par une question.", "Annoncez trois parties dès l'ouverture.", "Placez un chiffre précis.", "Utilisez une métaphore.", "Terminez par un appel à l'action.", "Aucun « euh » : remplacez-les par des silences.", "Racontez un souvenir personnel.", "Prenez la position opposée à la vôtre."];
  var SOUFFLE = [
    { id: "diaphragme", t: "Respiration diaphragmatique", d: "La base du souffle de l'orateur : le ventre se gonfle à l'inspiration, la poitrine reste calme.", seq: [["Inspirez par le ventre", 4], ["Expirez lentement", 6]], cycles: 6 },
    { id: "coherence", t: "Cohérence cardiaque 5/5", d: "Cinq secondes d'inspiration, cinq d'expiration : six respirations par minute. Idéale avant d'entrer en scène.", seq: [["Inspirez", 5], ["Expirez", 5]], cycles: 18 },
    { id: "carree", t: "Respiration carrée", d: "Quatre temps égaux pour retrouver la maîtrise quand la pression monte.", seq: [["Inspirez", 4], ["Retenez", 4], ["Expirez", 4], ["Poumons vides", 4]], cycles: 6 },
    { id: "prolongee", t: "Expiration prolongée", d: "Une expiration deux fois plus longue que l'inspiration ralentit le rythme cardiaque.", seq: [["Inspirez", 4], ["Expirez", 8]], cycles: 6 },
    { id: "soupir", t: "Double inspiration", d: "Deux inspirations successives par le nez, puis une longue expiration par la bouche : le moyen le plus rapide de relâcher la tension.", seq: [["Inspirez", 2], ["Inspirez encore", 1], ["Expirez longuement", 6]], cycles: 5 },
    { id: "478", t: "Respiration 4-7-8", d: "Inspirer sur quatre temps, retenir sur sept, expirer sur huit : un exercice d'apaisement à pratiquer la veille.", seq: [["Inspirez", 4], ["Retenez", 7], ["Expirez", 8]], cycles: 4 }
  ];
  var RITUEL = [["Une minute", "Respiration diaphragmatique, les mains posées sur le ventre."], ["Une minute", "Cohérence cardiaque 5/5."], ["Une minute", "Lecture lente, à voix basse, de votre première phrase."], ["Une minute", "Visualisation : le public, la salle, votre première phrase dite avec calme."], ["Une minute", "Silence complet, les deux pieds ancrés au sol."]];
  var VOIX = {
    vocalises: ["Mi, mé, ma, mo, mu : en ouvrant exagérément la bouche, du grave vers l'aigu.", "Bra, bré, bri, bro, bru, puis pra, pré, pri, pro, pru.", "La sirène : glissez sur un « ou » du plus grave au plus aigu, puis redescendez.", "Le bourdonnement : bouche fermée, faites vibrer un « mmm » en sentant les lèvres chatouiller.", "Comptez de un à dix en montant d'un ton à chaque chiffre, puis redescendez.", "Le « ng » prolongé, puis ouvrez sur « ngaaa » pour placer la voix vers l'avant."],
    virelangues: ["Les chaussettes de l'archiduchesse sont-elles sèches, archi-sèches ?", "Un chasseur sachant chasser doit savoir chasser sans son chien.", "Si six scies scient six cyprès, six cents scies scient six cents cyprès.", "Ton thé t'a-t-il ôté ta toux ?", "Je veux et j'exige d'exquises excuses.", "Trois tortues trottaient sur un trottoir très étroit.", "Pour qui sont ces serpents qui sifflent sur vos têtes ?", "Panier, piano. Panier, piano. Panier, piano.", "Cinq chiens chassent six chats.", "Un pâtissier qui pâtissait chez un tapissier qui tapissait…"],
    diction: ["Lisez un paragraphe avec un crayon tenu entre les dents, puis relisez-le sans : la différence de netteté est immédiate.", "Articulez chaque consonne finale d'une phrase : « Le public attend, il écoute, il décide. »", "Lisez un texte en exagérant toutes les voyelles, comme si vous parliez à une personne sourde à vingt mètres.", "Chuchotez un texte de façon parfaitement compréhensible : seule l'articulation porte le sens.", "Lisez une phrase trois fois : très lentement, à vitesse normale, très vite, sans perdre une syllabe."]
  };
  var POSTURE = [
    { t: "L'ancrage", s: 60, d: "Debout, pieds parallèles à la largeur des hanches, poids réparti. Relâchez les épaules, allongez la nuque. Restez immobile et respirez : c'est votre position de départ." },
    { t: "Le regard en triangle", s: 60, d: "Choisissez trois points dans la pièce (gauche, centre, droite). Dites une phrase complète à chacun, sans balayer : une idée, un regard." },
    { t: "Les gestes ouverts", s: 60, d: "Parlez d'un sujet libre en gardant les mains entre la taille et les épaules, paumes visibles. Interdiction de croiser les bras ou de toucher votre visage." },
    { t: "Le silence avant de répondre", s: 45, d: "Faites-vous poser des questions. Avant chaque réponse, comptez intérieurement jusqu'à trois. Les grands orateurs prennent ce temps : il signale la réflexion, non l'hésitation." },
    { t: "L'occupation de l'espace", s: 90, d: "Associez chaque partie de votre propos à un emplacement. Déplacez-vous seulement entre deux idées, jamais pendant une phrase." },
    { t: "Le visage", s: 45, d: "Racontez une bonne nouvelle, puis une mauvaise, en laissant le visage accompagner le sens. Filmez-vous : le visage dit souvent l'inverse de ce que l'on croit." }
  ];
  var DISCOURS = [
    { t: "L'Appel du 18 juin", a: "Charles de Gaulle · Londres, 1940", ctx: "Au lendemain de la demande d'armistice, un général presque inconnu parle à la radio de Londres à un pays qu'il ne voit pas.", ethos: "Il parle en militaire qui connaît la guerre et refuse d'en tirer la conclusion de la défaite ; sa crédibilité tient à la précision de son analyse.", pathos: "La flamme de la résistance, l'honneur, la foi dans l'avenir : l'émotion est contenue, jamais plaintive.", logos: "Le raisonnement est stratégique : la guerre est mondiale, l'empire et les alliés restent, la bataille de France n'est pas la guerre.", fleur: "F · Il reconnaît d'abord la situation. É · Il démontre que la défaite n'est pas définitive. R · Il termine par un appel concret à le rejoindre.", lecon: "Un discours court peut changer le cours des choses s'il apporte un raisonnement là où règne la sidération." },
    { t: "« I Have a Dream »", a: "Martin Luther King · Washington, 1963", ctx: "Devant plus de deux cent mille personnes, au terme de la Marche pour l'emploi et la liberté.", ethos: "Pasteur et militant, il parle au nom de principes que l'Amérique a elle-même proclamés.", pathos: "La répétition, les images bibliques et la vision d'enfants réunis créent une émotion collective.", logos: "La métaphore du chèque sans provision transforme une injustice en dette que le pays doit honorer.", fleur: "L · Il lie sa cause aux textes fondateurs du pays. U · Le rêve devient un « nous ». R · Le final transforme l'émotion en espérance partagée.", lecon: "L'anaphore n'est pas un ornement : elle donne au public un rythme qu'il peut porter avec vous." },
    { t: "Discours sur l'IVG", a: "Simone Veil · Assemblée nationale, 1974", ctx: "Ministre de la Santé, elle défend devant une assemblée presque entièrement masculine un projet de loi très contesté.", ethos: "Sa gravité et sa retenue lui donnent l'autorité de quelqu'un qui ne cherche pas à plaire.", pathos: "Elle parle de la détresse des femmes sans jamais céder au pathétique.", logos: "Elle part des faits (les avortements clandestins existent) pour démontrer que la loi doit encadrer plutôt qu'ignorer.", fleur: "F · Elle fonde son propos sur une réalité que nul ne peut nier. É · Elle éclaire chaque objection. U · Elle cherche un terrain commun avec ses adversaires.", lecon: "Face à une salle hostile, la sobriété et les faits portent plus loin que l'indignation." },
    { t: "Discours sur l'abolition de la peine de mort", a: "Robert Badinter · Assemblée nationale, 1981", ctx: "Garde des Sceaux, il présente le projet de loi d'abolition alors que l'opinion y est majoritairement opposée.", ethos: "Avocat qui a plaidé contre la peine capitale, il parle d'expérience et assume une conviction ancienne.", pathos: "Il convoque la responsabilité de la représentation nationale devant l'histoire.", logos: "Il démontre que la peine de mort n'a pas d'effet dissuasif établi et qu'elle rend l'erreur judiciaire irréparable.", fleur: "É · Les arguments sont ordonnés et documentés. U · Il inscrit le vote dans l'histoire de la nation. R · Il appelle à un choix de civilisation.", lecon: "Convaincre contre l'opinion exige d'élever le débat : déplacer la question du fait divers vers le principe." },
    { t: "Déclaration au procès de Rivonia", a: "Nelson Mandela · Pretoria, 1964", ctx: "Accusé de sabotage et passible de la peine de mort, il choisit de lire une déclaration depuis le banc des accusés.", ethos: "Il assume ses actes et ses idées : sa crédibilité naît de son refus de se défendre à n'importe quel prix.", pathos: "La dignité, plus que la colère : il parle d'un idéal pour lequel il est prêt à mourir.", logos: "Il expose méthodiquement les raisons qui ont conduit le mouvement de la non-violence à d'autres formes d'action.", fleur: "F · Il fonde son propos sur son histoire. É · Il explique, pas à pas, ses choix. R · La conclusion engage toute sa vie.", lecon: "La parole la plus forte est celle qui coûte quelque chose à celui qui la prononce." }
  ];
  var CRITERES = ["Mon ouverture a capté l'attention", "J'ai annoncé où j'allais", "Mon message central était clair", "J'ai donné au moins un exemple concret", "J'ai regardé l'ensemble de mon public", "Ma posture était ancrée et ouverte", "Mon débit était maîtrisé", "J'ai utilisé des silences", "Ma voix était variée et audible", "J'ai limité les tics verbaux", "J'ai répondu calmement aux questions", "Ma conclusion appelait à agir"];
  var PARCOURS = [
    { t: "Démosthène", s: "Les fondations", e: ["Pratiquer chaque jour la respiration diaphragmatique", "Lire un texte à voix haute dix minutes par jour", "Travailler trois virelangues jusqu'à la vitesse normale", "Mesurer son débit de référence au Laboratoire", "Tenir une minute d'ancrage sans bouger", "Prendre la parole une fois en réunion ou en groupe"] },
    { t: "Cicéron", s: "La structure", e: ["Remplir une fiche F.L.E.U.R. complète", "Écrire mot à mot une ouverture et une conclusion", "Réduire un message à une seule phrase", "Préparer trois arguments avec une preuve chacun", "Répondre à une objection avec la méthode P.O.N.T.", "Prononcer un discours de trois minutes chronométré"] },
    { t: "Format TED", s: "L'impact", e: ["Construire un récit personnel en trois temps", "Tenir cinq minutes d'improvisation sur un sujet tiré", "Utiliser le prompteur pour une répétition complète", "Se filmer et compléter l'auto-évaluation", "Obtenir un retour d'une personne de confiance", "Prononcer un discours de dix minutes devant un public"] }
  ];

  /* ------------------------------------------------ Navigation par espaces */
  var SPACES = [["evaluer", "Évaluer ma parole", "Diagnostic vocal au micro"], ["entrainer", "M'entraîner", "Souffle, voix, improvisation, posture"], ["preparer", "Préparer une intervention", "F.L.E.U.R., prompteur, grands discours"], ["suivre", "Suivre mes progrès", "Auto-évaluation, parcours, historique"]];
  var space = LP.single ? "" : (location.hash || "").slice(1);
  if (!SPACES.some(function (s) { return s[0] === space; })) space = "evaluer";
  var sub = { entrainer: "souffle", preparer: "fleur" };
  root.innerHTML = '<div class="lab-tabs" role="tablist">' + SPACES.map(function (s, i) { return '<button type="button" role="tab" data-s="' + s[0] + '"><span class="num">0' + (i + 1) + '</span><b>' + s[1] + '</b><small>' + s[2] + '</small></button>'; }).join("") + '</div><div id="lab-body"></div>';
  var body = $("#lab-body");
  $$(".lab-tabs button", root).forEach(function (b) { b.addEventListener("click", function () { space = b.getAttribute("data-s"); if (!LP.single) { try { history.replaceState(null, "", "#" + space); } catch (e) {} } draw(); }); });
  if (!LP.single) window.addEventListener("hashchange", function () { var h = location.hash.slice(1); if (h && h !== space && SPACES.some(function (s) { return s[0] === h; })) { space = h; draw(); } });
  function subtabs(list, cur, key) {
    return '<div class="subtabs">' + list.map(function (x) { return '<button type="button" data-sub="' + x[0] + '" aria-pressed="' + (x[0] === cur) + '">' + x[1] + '</button>'; }).join("") + '</div>';
  }
  function bindSub(key) { $$("[data-sub]", body).forEach(function (b) { b.addEventListener("click", function () { sub[key] = b.getAttribute("data-sub"); draw(); }); }); }
  function draw() {
    clearAll();
    $$(".lab-tabs button", root).forEach(function (b) { b.setAttribute("aria-selected", b.getAttribute("data-s") === space); });
    ({ evaluer: evaluer, entrainer: entrainer, preparer: preparer, suivre: suivre })[space]();
  }

  /* ------------------------------------------------ 01 Évaluer ma parole */
  var mic = null;
  function stopMic() {
    if (!mic) return;
    try { mic.stream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {}
    try { mic.ctx.close(); } catch (e) {}
    try { if (mic.rec) { mic.rec.onend = null; mic.rec.stop(); } } catch (e) {}
    mic = null;
  }
  var TEXTE = "Mesdames et Messieurs, nous sommes réunis pour prendre une décision qui engage notre organisation pour les trois prochaines années. Je vais vous présenter la situation, les options qui s'offrent à nous et la recommandation que je vous soumets. Notre activité a progressé, mais nos délais se sont allongés, et nos clients le remarquent. Nous pouvons attendre, ajuster à la marge, ou investir maintenant dans une organisation plus simple. Je vous propose la troisième voie, parce qu'elle protège ce que nous avons construit et prépare ce que nous voulons devenir. Je vous demande aujourd'hui de valider ce choix.";
  var TICS = ["euh", "heu", "du coup", "en fait", "voilà", "genre", "bah", "ben", "quoi", "effectivement", "donc voilà", "tu vois", "vous voyez"];
  var evalMode = "libre", evalSujet = rnd(SUJETS);
  function evaluer() {
    var prompt = evalMode === "lecture" ? TEXTE : evalMode === "impose" ? evalSujet : "Parlez d'un sujet de votre choix : votre métier, un projet, une conviction.";
    body.innerHTML = '<div class="lab-grid"><div class="panel"><span class="k">Diagnostic vocal en direct</span><h3>Parlez de soixante à cent vingt secondes</h3><p class="muted">Le volume, la hauteur, le débit, les silences et les tics verbaux sont mesurés pendant que vous parlez. Tout reste sur votre appareil.</p>' +
      subtabs([["libre", "Sujet libre"], ["impose", "Sujet imposé"], ["lecture", "Lecture d'un texte"]], evalMode, "eval") +
      '<div class="prompt-box" id="ev-prompt">' + esc(prompt) + '</div>' +
      (evalMode === "impose" ? '<button type="button" class="link" id="ev-new" style="justify-self:start">Autre sujet</button>' : "") +
      '<div class="actions"><button type="button" class="btn" id="ev-go">Commencer l\'enregistrement ' + ARROW + '</button><button type="button" class="btn btn-ghost" id="ev-chrono">Mesure chronométrée sans micro</button></div><p class="note" id="ev-state">Prêt. Votre navigateur vous demandera l\'accès au micro.</p></div>' +
      '<div class="panel" id="ev-live"><span class="k">Indicateurs</span><div class="vu"><i id="ev-vu" style="width:0"></i></div>' +
      '<div class="indicators"><div><span>Volume</span><b id="iv-vol">0</b><small>sur 100</small></div><div><span>Hauteur</span><b id="iv-hz">—</b><small>Hz</small></div><div><span>Débit</span><b id="iv-wpm">—</b><small>mots / min</small></div><div><span>Tics</span><b id="iv-tics">0</b><small>détectés</small></div><div><span>Silences</span><b id="iv-sil">0</b><small>pauses nettes</small></div><div><span>Durée</span><b id="iv-dur">0:00</b><small>minutes</small></div></div>' +
      '<span class="k">Transcription en direct</span><div class="transcript" id="ev-tr"><span class="muted">La transcription s\'affiche ici si votre navigateur la permet (Chrome, Edge ou Safari récents).</span></div>' +
      '<p class="note">Aucun enregistrement n\'est conservé ni transmis à Lead Performant. La transcription utilise le service de reconnaissance vocale de votre navigateur ; selon le navigateur, l\'audio peut être traité par son éditeur. L\'entraînement reste possible sans elle.</p></div></div><div id="ev-debrief"></div>';
    $$("[data-sub]", body).forEach(function (b) { b.addEventListener("click", function () { evalMode = b.getAttribute("data-sub"); draw(); }); });
    var nw = $("#ev-new"); if (nw) nw.addEventListener("click", function () { evalSujet = rnd(SUJETS); $("#ev-prompt").textContent = evalSujet; });
    $("#ev-go").addEventListener("click", function () { if (mic) finish(); else start(); });
    $("#ev-chrono").addEventListener("click", chrono);
  }
  function start() {
    var state = $("#ev-state");
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { state.textContent = "Votre navigateur ne donne pas accès au micro. Utilisez la mesure chronométrée."; return; }
    state.textContent = "Demande d'accès au micro…";
    navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } }).then(function (stream) {
      var AC = window.AudioContext || window.webkitAudioContext, ctx = new AC();
      var src = ctx.createMediaStreamSource(stream), an = ctx.createAnalyser(); an.fftSize = 2048; src.connect(an);
      mic = { stream: stream, ctx: ctx, an: an, buf: new Float32Array(an.fftSize), t0: performance.now(), vols: [], pitches: [], sil: 0, inSil: false, silStart: 0, spoke: false, words: 0, text: "", interim: "", tics: 0, ticList: {} };
      var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SR) {
        try {
          var rec = new SR(); rec.lang = "fr-FR"; rec.continuous = true; rec.interimResults = true;
          rec.onresult = function (e) {
            var interim = "";
            for (var i = e.resultIndex; i < e.results.length; i++) {
              var t = e.results[i][0].transcript;
              if (e.results[i].isFinal) mic.text += (mic.text ? " " : "") + t.trim(); else interim += t;
            }
            mic.interim = interim; renderTranscript();
          };
          rec.onend = function () { if (mic && mic.rec === rec) { try { rec.start(); } catch (e) {} } };
          rec.onerror = function () {};
          rec.start(); mic.rec = rec;
        } catch (e) {}
      } else { $("#ev-tr").innerHTML = '<span class="muted">La transcription n\'est pas disponible dans ce navigateur : le débit et les tics ne pourront pas être mesurés. Le volume, la hauteur et les silences restent mesurés.</span>'; }
      $("#ev-go").innerHTML = "Arrêter et voir le débrief " + ARROW;
      state.innerHTML = '<span class="rec-dot"></span>Enregistrement en cours. Parlez naturellement.';
      loop();
      timers.push(setTimeout(function () { if (mic) finish(); }, 180000));
    }).catch(function () { state.textContent = "L'accès au micro a été refusé ou n'est pas disponible ici. Autorisez le micro dans votre navigateur, ou utilisez la mesure chronométrée."; });
  }
  function renderTranscript() {
    var all = (mic.text + " " + mic.interim).trim();
    mic.words = mic.text ? mic.text.split(/\s+/).length : 0;
    var low = " " + mic.text.toLowerCase().replace(/[.,;:!?]/g, " ") + " ", n = 0, list = {};
    TICS.forEach(function (t) { var m = low.split(" " + t + " ").length - 1; if (m > 0) { n += m; list[t] = m; } });
    mic.tics = n; mic.ticList = list;
    var html = esc(all);
    TICS.forEach(function (t) { html = html.replace(new RegExp("(^|\\s)(" + t.replace(/ /g, "\\s") + ")(?=[\\s.,;!?]|$)", "gi"), "$1<mark>$2</mark>"); });
    var tr = $("#ev-tr"); if (tr) { tr.innerHTML = html || '<span class="muted">À l\'écoute…</span>'; tr.scrollTop = tr.scrollHeight; }
    $("#iv-tics").textContent = n;
  }
  function pitchOf(buf, rate) {
    var n = buf.length, best = -1, bestCor = 0, minL = Math.floor(rate / 400), maxL = Math.floor(rate / 70);
    var rms = 0; for (var i = 0; i < n; i++) rms += buf[i] * buf[i]; rms = Math.sqrt(rms / n); if (rms < 0.02) return 0;
    for (var lag = minL; lag <= maxL; lag++) { var c = 0; for (var j = 0; j < n - lag; j++) c += buf[j] * buf[j + lag]; if (c > bestCor) { bestCor = c; best = lag; } }
    return best > 0 ? rate / best : 0;
  }
  var lastP = 0;
  function loop() {
    if (!mic) return;
    mic.an.getFloatTimeDomainData(mic.buf);
    var s = 0; for (var i = 0; i < mic.buf.length; i++) s += mic.buf[i] * mic.buf[i];
    var rms = Math.sqrt(s / mic.buf.length), vol = Math.min(100, Math.round(rms * 420));
    var now = performance.now(), el = (now - mic.t0) / 1000;
    $("#ev-vu").style.width = vol + "%"; $("#iv-vol").textContent = vol; $("#iv-dur").textContent = fmt(el);
    if (vol > 6) { mic.spoke = true; mic.vols.push(vol); }
    if (mic.spoke) {
      if (vol < 4) { if (!mic.inSil) { mic.inSil = true; mic.silStart = now; } }
      else { if (mic.inSil && now - mic.silStart > 700) { mic.sil++; $("#iv-sil").textContent = mic.sil; } mic.inSil = false; }
    }
    if (now - lastP > 120) { lastP = now; var p = pitchOf(mic.buf, mic.ctx.sampleRate); if (p) { mic.pitches.push(p); $("#iv-hz").textContent = Math.round(p); } }
    if (mic.words && el > 5) $("#iv-wpm").textContent = Math.round(mic.words / (el / 60));
    var id = requestAnimationFrame(loop); timers.push(id);
  }
  function finish() {
    if (!mic) return;
    var m = mic, el = (performance.now() - m.t0) / 1000;
    if (m.rec) { try { m.rec.onend = null; m.rec.stop(); } catch (e) {} }
    var hasText = !!(m.rec && m.text);
    stopMic(); clearAll();
    $("#ev-go").innerHTML = "Recommencer " + ARROW; $("#ev-state").textContent = "Enregistrement terminé.";
    if (el < 15) { $("#ev-debrief").innerHTML = '<div class="panel" style="margin-top:28px"><p>L\'enregistrement est trop court pour un débrief fiable. Parlez au moins une minute.</p></div>'; return; }
    var wpm = hasText ? Math.round(m.text.split(/\s+/).length / (el / 60)) : null;
    var semis = []; m.pitches.forEach(function (p) { semis.push(12 * Math.log(p / 100) / Math.LN2); });
    var mean = semis.reduce(function (a, b) { return a + b; }, 0) / (semis.length || 1);
    var sd = Math.sqrt(semis.reduce(function (a, b) { return a + (b - mean) * (b - mean); }, 0) / (semis.length || 1));
    var vmean = m.vols.reduce(function (a, b) { return a + b; }, 0) / (m.vols.length || 1);
    var silPerMin = m.sil / (el / 60);
    var obs = [];
    obs.push(["Débit", wpm === null ? "Non mesuré : la transcription n'était pas disponible." : wpm + " mots par minute. " + (wpm < 120 ? "Un rythme posé ; veillez à garder l'énergie sur les mots clés." : wpm <= 160 ? "Dans la zone de confort de l'auditoire (120 à 160)." : "Rapide : marquez un silence d'une seconde entre chaque idée.")]);
    obs.push(["Silences", m.sil + " pauses nettes, soit " + silPerMin.toFixed(1).replace(".", ",") + " par minute. " + (silPerMin < 2 ? "Osez davantage le silence : il signale la maîtrise et laisse l'idée s'installer." : silPerMin > 8 ? "Beaucoup d'interruptions : préparez mieux l'enchaînement de vos idées." : "Un usage équilibré du silence.")]);
    obs.push(["Mélodie", semis.length < 20 ? "Pas assez de voix détectée pour juger la mélodie." : (sd < 1.8 ? "Votre voix varie peu : appuyez les mots clés et changez de hauteur entre deux idées." : sd > 5 ? "Une voix très mobile : gardez une ligne stable pour les messages importants." : "Une mélodie variée, qui soutient l'attention.")]);
    obs.push(["Volume", "Niveau moyen " + Math.round(vmean) + " sur 100. " + (vmean < 18 ? "Parlez plus fort, ou rapprochez-vous du micro : la voix doit atteindre le dernier rang." : "Un volume suffisant.")]);
    obs.push(["Tics verbaux", !hasText ? "Non mesurés sans transcription." : m.tics === 0 ? "Aucun tic détecté." : m.tics + " occurrences : " + Object.keys(m.ticList).map(function (k) { return "« " + k + " » (" + m.ticList[k] + ")"; }).join(", ") + ". Remplacez-les par un silence."]);
    hist.add({ k: "Diagnostic vocal", v: (wpm ? wpm + " mots/min · " : "") + m.sil + " silences · " + fmt(el), wpm: wpm });
    $("#ev-debrief").innerHTML = '<div class="panel fade-in" style="margin-top:28px"><span class="k">Débrief · ' + fmt(el) + '</span><h3>Ce que votre voix nous dit</h3><ul class="obs">' + obs.map(function (o) { return "<li><b>" + o[0] + "</b><span>" + esc(o[1]) + "</span></li>"; }).join("") + '</ul><div class="exercise"><span class="eyebrow">Repère</span><p class="muted" style="margin-top:6px">Ralentir l\'expiration apaise le rythme cardiaque. Un débit de 120 à 160 mots par minute et des silences assumés sont généralement perçus comme des signes de maîtrise.</p></div><p class="caveat">Ces indicateurs sont des repères d\'entraînement calculés par votre navigateur ; ils ne constituent pas une évaluation de votre éloquence.</p></div>';
    $("#ev-debrief").scrollIntoView({ behavior: "smooth", block: "start" });
  }
  function chrono() {
    clearAll();
    var words = TEXTE.split(/\s+/).length, t0 = 0, run = false;
    $("#ev-debrief").innerHTML = '<div class="panel fade-in" style="margin-top:28px"><span class="k">Mesure chronométrée · ' + words + ' mots</span><h3>Lisez ce texte à voix haute, comme devant un comité</h3><div class="prompt-box">' + esc(TEXTE) + '</div><div class="timer" id="ch-t">0:00</div><div class="actions" style="justify-content:center"><button type="button" class="btn" id="ch-go">Démarrer la lecture</button></div><div id="ch-res"></div></div>';
    $("#ev-debrief").scrollIntoView({ behavior: "smooth", block: "start" });
    var iv;
    $("#ch-go").addEventListener("click", function () {
      if (!run) { run = true; t0 = performance.now(); this.textContent = "J'ai terminé"; $("#ch-t").classList.add("live"); iv = setInterval(function () { $("#ch-t").textContent = fmt((performance.now() - t0) / 1000); }, 200); timers.push(iv); $("#ch-res").innerHTML = ""; return; }
      run = false; clearInterval(iv); $("#ch-t").classList.remove("live"); this.textContent = "Recommencer";
      var s = (performance.now() - t0) / 1000;
      if (s < 10) { $("#ch-res").innerHTML = '<p class="muted" style="text-align:center">Lecture trop courte : lisez le texte en entier.</p>'; return; }
      var wpm = Math.round(words / (s / 60));
      hist.add({ k: "Débit chronométré", v: wpm + " mots/min", wpm: wpm });
      $("#ch-res").innerHTML = '<ul class="obs"><li><b>Débit</b><span>' + wpm + ' mots par minute. ' + (wpm < 120 ? "Un rythme posé ; gardez l'énergie sur les mots clés." : wpm <= 160 ? "Dans la zone de confort de l'auditoire." : "Rapide : marquez un silence entre chaque idée.") + '</span></li></ul>';
    });
  }

  /* ------------------------------------------------ 02 M'entraîner */
  var impro = { sujet: rnd(SUJETS), dur: 90, contrainte: null };
  var voixTab = "virelangues", voixIx = 0;
  function entrainer() {
    var cur = sub.entrainer;
    body.innerHTML = subtabs([["souffle", "Le souffle"], ["voix", "Voix et articulation"], ["impro", "Improvisation"], ["posture", "Posture et présence"]], cur) + '<div id="tr-body"></div>';
    bindSub("entrainer");
    var b = $("#tr-body");
    if (cur === "souffle") {
      var tech = SOUFFLE[0];
      b.innerHTML = '<div class="lab-grid"><div class="panel"><span class="k">Six respirations guidées</span><div class="field"><label for="sf-t">Choisissez une technique</label><select id="sf-t">' + SOUFFLE.map(function (s) { return '<option value="' + s.id + '">' + s.t + '</option>'; }).join("") + '</select></div><p class="muted" id="sf-d"></p><div class="breath-stage"><div class="breath" id="sf-c"><span><b>Prêt</b><small id="sf-n"></small></span></div></div><div class="actions" style="justify-content:center"><button type="button" class="btn" id="sf-go">Commencer</button><button type="button" class="btn btn-ghost" id="sf-reset">Réinitialiser</button></div></div>' +
        '<div class="panel"><span class="k">Boîte à outils</span><h3>Le rituel des cinq minutes</h3><p class="muted">Avant une prise de parole importante, dans cet ordre :</p><ul class="list-plain">' + RITUEL.map(function (r) { return "<li><b>" + r[0] + "</b> · " + r[1] + "</li>"; }).join("") + '</ul></div></div>';
      var sel = $("#sf-t"), c = $("#sf-c"), lab = $("b", c), n = $("#sf-n");
      var desc = function () { tech = SOUFFLE.filter(function (s) { return s.id === sel.value; })[0]; $("#sf-d").textContent = tech.d; n.textContent = tech.cycles + " cycles"; };
      sel.addEventListener("change", function () { clearAll(); reset(); desc(); }); desc();
      function reset() { c.style.transitionDuration = ".6s"; c.style.transform = "scale(.72)"; lab.textContent = "Prêt"; n.textContent = tech.cycles + " cycles"; }
      $("#sf-reset").addEventListener("click", function () { clearAll(); reset(); });
      $("#sf-go").addEventListener("click", function () {
        clearAll(); var cyc = 0, ph = 0;
        (function step() {
          if (cyc >= tech.cycles) { lab.textContent = "Terminé"; n.textContent = "Bravo"; c.style.transform = "scale(.72)"; hist.add({ k: "Souffle", v: tech.t }); return; }
          var p = tech.seq[ph], txt = p[0].toLowerCase();
          var scale = txt.indexOf("inspir") > -1 ? 1 : txt.indexOf("expir") > -1 ? .62 : null;
          c.style.transitionDuration = p[1] + "s"; if (scale) c.style.transform = "scale(" + scale + ")";
          lab.textContent = p[0]; n.textContent = "Cycle " + (cyc + 1) + " sur " + tech.cycles;
          timers.push(setTimeout(function () { ph = (ph + 1) % tech.seq.length; if (ph === 0) cyc++; step(); }, p[1] * 1000));
        })();
      });
    }
    if (cur === "voix") {
      var list = VOIX[voixTab];
      b.innerHTML = '<div class="lab-grid"><div class="panel"><div class="subtabs" style="margin:0">' + [["vocalises", "Vocalises"], ["virelangues", "Virelangues"], ["diction", "Diction"]].map(function (x) { return '<button type="button" data-v="' + x[0] + '" aria-pressed="' + (x[0] === voixTab) + '">' + x[1] + '</button>'; }).join("") + '</div><div class="prompt-box" id="vx-p" style="min-height:120px">' + esc(list[voixIx % list.length]) + '</div><p class="note">Exercice ' + (voixIx % list.length + 1) + ' sur ' + list.length + '</p><div class="actions"><button type="button" class="btn" id="vx-next">Suivant</button><button type="button" class="btn btn-ghost" id="vx-rnd">Au hasard</button></div></div>' +
        '<div class="panel"><span class="k">Consignes</span><ul class="list-plain"><li>Dites chaque virelangue trois fois lentement, en exagérant l\'articulation, puis trois fois à vitesse normale.</li><li>Pour les vocalises, ouvrez la bouche plus que vous ne le croyez nécessaire.</li><li>Gardez la nuque longue et les épaules relâchées : la voix vient du souffle, pas de la gorge.</li><li>Dix minutes par jour valent mieux qu\'une heure par semaine.</li></ul></div></div>';
      $$("[data-v]", b).forEach(function (x) { x.addEventListener("click", function () { voixTab = x.getAttribute("data-v"); voixIx = 0; entrainer(); }); });
      $("#vx-next").addEventListener("click", function () { voixIx++; entrainer(); });
      $("#vx-rnd").addEventListener("click", function () { voixIx = Math.floor(Math.random() * list.length); entrainer(); });
    }
    if (cur === "impro") {
      b.innerHTML = '<div class="lab-grid"><div class="panel"><span class="k">Soixante sujets</span><div class="prompt-box" id="im-s">' + esc(impro.sujet) + '</div>' + (impro.contrainte ? '<p><b>Contrainte :</b> ' + esc(impro.contrainte) + '</p>' : "") +
        '<div class="field"><span class="label">Durée</span><div class="seg" id="im-d">' + [[45, "45 s"], [90, "1 min 30"], [180, "3 min"], [300, "5 min"]].map(function (d) { return '<button type="button" data-d="' + d[0] + '" aria-pressed="' + (impro.dur === d[0]) + '">' + d[1] + '</button>'; }).join("") + '</div></div>' +
        '<div class="timer" id="im-t">' + fmt(impro.dur) + '</div><div class="actions" style="justify-content:center"><button type="button" class="btn" id="im-go">Démarrer</button><button type="button" class="btn btn-ghost" id="im-new">Nouveau sujet</button><button type="button" class="link" id="im-c">' + (impro.contrainte ? "Retirer la contrainte" : "Ajouter une contrainte") + '</button></div><div id="im-end"></div></div>' +
        '<div class="panel"><span class="k">Méthode</span><h3>Une idée, un exemple, une conclusion</h3><ul class="list-plain"><li><b>Ouvrir</b> · reformulez le sujet ou posez une question.</li><li><b>Prendre position</b> · une seule idée, annoncée clairement.</li><li><b>Illustrer</b> · un exemple vécu ou observé.</li><li><b>Conclure</b> · revenez à votre idée et arrêtez-vous net.</li></ul></div></div>';
      $$("#im-d button", b).forEach(function (x) { x.addEventListener("click", function () { impro.dur = +x.getAttribute("data-d"); entrainer(); }); });
      $("#im-new").addEventListener("click", function () { impro.sujet = rnd(SUJETS); if (impro.contrainte) impro.contrainte = rnd(CONTRAINTES); entrainer(); });
      $("#im-c").addEventListener("click", function () { impro.contrainte = impro.contrainte ? null : rnd(CONTRAINTES); entrainer(); });
      $("#im-go").addEventListener("click", function () {
        clearAll(); var left = impro.dur, t = $("#im-t"); t.classList.add("live"); this.disabled = true;
        var iv = setInterval(function () {
          left--; t.textContent = fmt(left);
          if (left <= 0) {
            clearInterval(iv); t.classList.remove("live"); t.textContent = "Terminé";
            var crit = ["J'ai ouvert sans hésiter", "J'ai pris une position claire", "J'ai donné un exemple", "J'ai conclu nettement", "J'ai tenu toute la durée"];
            $("#im-end").innerHTML = '<div class="check-list">' + crit.map(function (c, i) { return '<label><input type="checkbox" value="' + i + '"> ' + c + '</label>'; }).join("") + '</div><div class="actions" style="margin-top:16px"><button type="button" class="btn" id="im-save">Enregistrer la séance</button></div>';
            $("#im-save").addEventListener("click", function () { var n = $$("#im-end input:checked").length; hist.add({ k: "Improvisation", v: n + "/5 · " + impro.sujet }); U.toast("Séance enregistrée"); $("#im-end").innerHTML = '<p class="muted">' + n + ' critères sur 5. ' + (n < 3 ? "Reprenez le même sujet en visant la structure." : "Tirez un nouveau sujet et allongez la durée.") + '</p>'; });
          }
        }, 1000); timers.push(iv);
      });
    }
    if (cur === "posture") {
      b.innerHTML = '<div class="g3">' + POSTURE.map(function (p, i) { return '<div class="panel"><span class="k">Exercice 0' + (i + 1) + ' · ' + fmt(p.s) + '</span><h3>' + p.t + '</h3><p class="muted">' + p.d + '</p><div class="timer" style="font-size:2.6rem" id="ps-t' + i + '">' + fmt(p.s) + '</div><button type="button" class="btn btn-ghost" data-p="' + i + '">Lancer le minuteur</button></div>'; }).join("") + '</div>';
      $$("[data-p]", b).forEach(function (x) {
        x.addEventListener("click", function () {
          var i = +x.getAttribute("data-p"), p = POSTURE[i], t = $("#ps-t" + i);
          if (x._iv) { clearInterval(x._iv); x._iv = null; t.textContent = fmt(p.s); t.classList.remove("live"); x.textContent = "Lancer le minuteur"; return; }
          var left = p.s; t.classList.add("live"); x.textContent = "Arrêter";
          x._iv = setInterval(function () { left--; t.textContent = fmt(left); if (left <= 0) { clearInterval(x._iv); x._iv = null; t.classList.remove("live"); t.textContent = "Terminé"; x.textContent = "Recommencer"; hist.add({ k: "Posture", v: p.t }); } }, 1000);
          timers.push(x._iv);
        });
      });
    }
  }

  /* ------------------------------------------------ 03 Préparer une intervention */
  var FLEUR = [["idee", "Mon idée centrale", "Ce que je veux qu'ils comprennent, en une phrase"], ["demande", "Ma demande", "Ce que je veux qu'ils fassent ou pensent ensuite"], ["f", "F · Fonder", "Ma première phrase, apprise par cœur. Elle annonce le vrai sujet."], ["l", "L · Lier", "En quoi cela les concerne, de leur point de vue"], ["e1", "É · Éclairer, argument 1 et sa preuve", ""], ["e2", "É · Éclairer, argument 2 et sa preuve", ""], ["lim", "É · Ce que je reconnais comme limite", ""], ["u", "U · Unir ou situer", "Ce que nous partageons réellement, ou là où passe exactement le désaccord"], ["r", "R · Réveiller", "Ma demande, proportionnée et libre, et ma dernière phrase, apprise par cœur"]];
  var dIx = 0;
  function preparer() {
    var cur = sub.preparer;
    body.innerHTML = subtabs([["fleur", "Fiche F.L.E.U.R."], ["prompteur", "Prompteur"], ["cadres", "Répondre et débattre"], ["discours", "Grands discours"]], cur) + '<div id="pr-body"></div>';
    bindSub("preparer");
    var b = $("#pr-body");
    if (cur === "fleur") {
      var d = store.get("fleur", {});
      b.innerHTML = '<div class="lab-grid"><div class="panel"><span class="k">Architecture du discours</span><h3>La fiche F.L.E.U.R.</h3><p class="muted">Fonder, Lier, Éclairer, Unir, Réveiller : cinq mouvements, une seule destination, l\'esprit de ceux qui écoutent. Remplissez la fiche sur une seule page, avant toute intervention.</p>' +
        FLEUR.map(function (f) { return '<div class="field"><label for="fl-' + f[0] + '">' + f[1] + '</label><textarea id="fl-' + f[0] + '" data-f="' + f[0] + '" style="min-height:70px" placeholder="' + esc(f[2]) + '">' + esc(d[f[0]] || "") + '</textarea></div>'; }).join("") + '</div>' +
        '<div class="panel" style="position:sticky;top:110px"><span class="k">Votre discours</span><div class="output" id="fl-out" style="white-space:pre-wrap;font-size:.98rem;line-height:1.75;min-height:200px"></div><div class="exercise"><span class="eyebrow">Le test</span><p class="muted" style="margin-top:6px">Une personne de confiance peut-elle redire votre idée centrale et votre demande après vous avoir écouté ?</p></div><div class="actions"><button type="button" class="btn" id="fl-pr">Envoyer au prompteur</button><button type="button" class="btn btn-ghost" id="fl-cp">Copier</button></div><p class="note">Brouillon sauvegardé dans votre navigateur.</p></div></div>';
      var outFn = function () {
        var o = {}; $$("textarea[data-f]", b).forEach(function (t) { o[t.getAttribute("data-f")] = t.value.trim(); }); store.set("fleur", o);
        var txt = [o.f, o.l, o.e1, o.e2, o.lim, o.u, o.r].filter(Boolean).join("\n\n");
        $("#fl-out").innerHTML = txt ? esc(txt) : '<span class="muted">Votre discours s\'assemble ici, dans l\'ordre F.L.E.U.R., au fil de votre saisie.</span>';
        return txt;
      };
      b.addEventListener("input", outFn); outFn();
      $("#fl-cp").addEventListener("click", function () { U.copy(outFn()); });
      $("#fl-pr").addEventListener("click", function () { var t = outFn(); if (!t) { U.toast("Complétez au moins une rubrique"); return; } store.set("prompteur", t); sub.preparer = "prompteur"; draw(); U.toast("Discours envoyé au prompteur"); });
    }
    if (cur === "prompteur") {
      var text = store.get("prompteur", "La parole est un acte. Elle engage celui qui la prononce et transforme ceux qui l'écoutent.\n\nUn orateur ne remplit pas un temps de parole : il construit un chemin. Il fonde l'attention, il relie son sujet à la vie de son public, il éclaire, il rassemble, puis il réveille.\n\nPréparez votre texte, réglez la vitesse, et lisez en regardant au-dessus de la ligne dorée.");
      var size = store.get("prompteur-size", 1.5), speed = store.get("prompteur-speed", 35);
      b.innerHTML = '<div class="lab-grid"><div class="panel" style="padding:0;overflow:hidden"><div class="prompter" id="pt"><span class="guide"></span><div class="inner" id="pt-in" style="font-size:' + size + 'rem">' + esc(text) + '</div></div></div>' +
        '<div class="panel"><span class="k">Réglages</span><div class="field"><label for="pt-sp">Vitesse : <span id="pt-spv">' + speed + '</span> px/s</label><input type="range" id="pt-sp" min="10" max="120" value="' + speed + '" style="accent-color:var(--navy)"></div>' +
        '<div class="field"><span class="label">Taille du texte</span><div class="seg" style="grid-template-columns:repeat(3,1fr)">' + [[1.5, "Normal"], [2, "Grand"], [2.6, "Très grand"]].map(function (s) { return '<button type="button" data-z="' + s[0] + '" aria-pressed="' + (size === s[0]) + '">' + s[1] + '</button>'; }).join("") + '</div></div>' +
        '<div class="actions"><button type="button" class="btn" id="pt-go">Démarrer</button><button type="button" class="btn btn-ghost" id="pt-re">Réinitialiser</button><button type="button" class="link" id="pt-fs">Plein écran</button></div>' +
        '<div class="field"><label for="pt-tx">Modifier le texte</label><textarea id="pt-tx" style="min-height:160px">' + esc(text) + '</textarea></div><p class="note">Le texte est enregistré dans votre navigateur.</p></div></div>';
      var pt = $("#pt"), pin = $("#pt-in"), playing = false, last = 0, acc = 0;
      $("#pt-sp").addEventListener("input", function () { speed = +this.value; $("#pt-spv").textContent = speed; store.set("prompteur-speed", speed); });
      $$("[data-z]", b).forEach(function (x) { x.addEventListener("click", function () { size = +x.getAttribute("data-z"); store.set("prompteur-size", size); pin.style.fontSize = size + "rem"; $$("[data-z]", b).forEach(function (y) { y.setAttribute("aria-pressed", y === x); }); }); });
      $("#pt-tx").addEventListener("input", function () { store.set("prompteur", this.value); pin.textContent = this.value; });
      function tick(t) {
        if (!playing) return;
        if (last) { acc += (t - last) / 1000 * speed; if (acc >= 1) { pt.scrollTop += Math.floor(acc); acc -= Math.floor(acc); } }
        last = t;
        if (pt.scrollTop + pt.clientHeight >= pt.scrollHeight - 2) { playing = false; $("#pt-go").textContent = "Démarrer"; hist.add({ k: "Prompteur", v: "Répétition complète" }); return; }
        timers.push(requestAnimationFrame(tick));
      }
      $("#pt-go").addEventListener("click", function () { playing = !playing; last = 0; this.textContent = playing ? "Pause" : "Reprendre"; if (playing) timers.push(requestAnimationFrame(tick)); });
      $("#pt-re").addEventListener("click", function () { playing = false; pt.scrollTop = 0; $("#pt-go").textContent = "Démarrer"; });
      $("#pt-fs").addEventListener("click", function () { var p = pt.requestFullscreen ? pt.requestFullscreen() : null; if (p && p.catch) p.catch(function () { U.toast("Le plein écran n'est pas disponible ici"); }); else if (!p) U.toast("Le plein écran n'est pas disponible ici"); });
    }
    if (cur === "cadres") {
      b.innerHTML = '<div class="g2"><div class="panel"><span class="k">Répondre à une question</span><h3>La méthode C.L.A.I.R.</h3><ul class="list-plain"><li><b>Comprendre</b> · écoutez la question jusqu\'au bout, reformulez si nécessaire.</li><li><b>Lier</b> · reliez-la à votre idée centrale.</li><li><b>Argumenter</b> · répondez en deux ou trois points.</li><li><b>Illustrer</b> · ajoutez un exemple concret.</li><li><b>Résumer</b> · concluez par une phrase forte, puis arrêtez-vous.</li></ul></div>' +
        '<div class="panel"><span class="k">Exprimer un désaccord</span><h3>La méthode P.O.N.T.</h3><ul class="list-plain"><li><b>Poser un accord</b> · « Je partage votre préoccupation concernant… »</li><li><b>Observer le désaccord</b> · précisément, sur l\'idée, jamais sur la personne.</li><li><b>Nourrir votre réponse</b> · des faits et des exemples, jamais des attaques.</li><li><b>Tendre la main</b> · « Comment pourrions-nous avancer ensemble sur cette question ? »</li></ul></div></div>';
    }
    if (cur === "discours") {
      var s = DISCOURS[dIx];
      b.innerHTML = '<div class="lab-grid" style="grid-template-columns:minmax(0,.75fr) minmax(0,1.25fr)"><div class="panel"><span class="k">Cinq discours analysés</span><div class="speech-list">' + DISCOURS.map(function (x, i) { return '<button type="button" data-i="' + i + '" aria-pressed="' + (i === dIx) + '"><span><b>' + x.t + '</b><br><small>' + x.a + '</small></span></button>'; }).join("") + '</div></div>' +
        '<div class="panel fade-in"><span class="k">' + s.a + '</span><h3 style="font-size:2rem">' + s.t + '</h3><p class="muted">' + s.ctx + '</p><ul class="obs"><li><b>Ethos · la crédibilité</b><span>' + s.ethos + '</span></li><li><b>Pathos · l\'émotion</b><span>' + s.pathos + '</span></li><li><b>Logos · la logique</b><span>' + s.logos + '</span></li><li><b>Architecture F.L.E.U.R.</b><span>' + s.fleur + '</span></li></ul><div class="exercise"><span class="eyebrow">La leçon</span><p class="big" style="font-size:1.3rem">' + s.lecon + '</p></div><p class="quote" style="font-size:1.3rem;max-width:none">« Les connaissances impressionnent. La parole influence. »</p></div></div>';
      $$("[data-i]", b).forEach(function (x) { x.addEventListener("click", function () { dIx = +x.getAttribute("data-i"); preparer(); }); });
    }
  }

  /* ------------------------------------------------ 04 Suivre mes progrès */
  function suivre() {
    var parc = store.get("parcours", {});
    body.innerHTML = '<div class="lab-grid"><div class="panel"><span class="k">Auto-évaluation</span><h3>Après chaque prise de parole</h3><p class="muted">Cochez les critères que vous avez tenus.</p><div class="check-list" id="ae">' + CRITERES.map(function (c, i) { return '<label><input type="checkbox" value="' + i + '"> ' + c + '</label>'; }).join("") + '</div><div style="display:flex;align-items:end;justify-content:space-between;gap:20px;flex-wrap:wrap"><div><span class="big-pct" id="ae-p">0 %</span><p class="note">Critères validés : <span id="ae-n">0</span>/12</p></div><div class="actions"><button type="button" class="btn" id="ae-s">Enregistrer ce bilan</button><button type="button" class="link" id="ae-r">Nouveau bilan</button></div></div></div>' +
      '<div class="panel"><span class="k">Ma progression</span><h3>Évolution de vos séances</h3><div id="charts"></div><ul class="hist" id="hl"></ul><button type="button" class="link" id="hclr" style="justify-self:start">Effacer l\'historique</button><p class="note">Vos séances sont conservées dans ce navigateur uniquement ; elles ne sont pas synchronisées entre vos appareils.</p></div></div>' +
      '<div class="head" style="margin-top:64px"><span class="eyebrow">Parcours</span><h2>Trois programmes progressifs</h2><p class="lede">Des classiques au standard moderne. Cochez chaque étape franchie : votre progression est sauvegardée.</p></div><div class="g3">' +
      PARCOURS.map(function (p, i) { var done = (parc[i] || []).length; return '<div class="panel"><span class="k">Programme 0' + (i + 1) + ' · ' + done + '/' + p.e.length + '</span><h3>' + p.t + '</h3><p class="muted">' + p.s + '</p><div class="check-list">' + p.e.map(function (e, j) { return '<label><input type="checkbox" data-p="' + i + '" data-e="' + j + '"' + ((parc[i] || []).indexOf(j) > -1 ? " checked" : "") + '> ' + e + '</label>'; }).join("") + '</div></div>'; }).join("") + '</div>';
    var upd = function () { var n = $$("#ae input:checked").length; $("#ae-n").textContent = n; $("#ae-p").textContent = Math.round(n / 12 * 100) + " %"; };
    $("#ae").addEventListener("change", upd);
    $("#ae-s").addEventListener("click", function () { var n = $$("#ae input:checked").length; var pct = Math.round(n / 12 * 100); hist.add({ k: "Auto-évaluation", v: pct + " %", pct: pct }); U.toast("Bilan enregistré"); drawHist(); });
    $("#ae-r").addEventListener("click", function () { $$("#ae input").forEach(function (x) { x.checked = false; }); upd(); });
    $$("[data-p]", body).forEach(function (x) { x.addEventListener("change", function () { var p = parc[x.getAttribute("data-p")] || [], e = +x.getAttribute("data-e"); var ix = p.indexOf(e); if (x.checked && ix < 0) p.push(e); if (!x.checked && ix > -1) p.splice(ix, 1); parc[x.getAttribute("data-p")] = p; store.set("parcours", parc); var k = x.closest(".panel").querySelector(".k"); k.textContent = "Programme 0" + (+x.getAttribute("data-p") + 1) + " · " + p.length + "/6"; }); });
    var clr = $("#hclr");
    clr.addEventListener("click", function () { if (clr.getAttribute("data-c")) { store.set("hist", []); clr.removeAttribute("data-c"); clr.textContent = "Effacer l'historique"; drawHist(); } else { clr.setAttribute("data-c", "1"); clr.textContent = "Confirmer l'effacement"; } });
    drawHist();
  }
  function chart(series, opt) {
    var W = 520, H = 160, pad = 28, n = series.length;
    if (n < 2) return '<p class="note" style="padding:12px 0">' + opt.empty + '</p>';
    var x = function (i) { return pad + i * (W - pad * 2) / (n - 1); }, y = function (v) { return H - pad - (v - opt.min) / (opt.max - opt.min) * (H - pad * 2); };
    var band = opt.band ? '<rect x="' + pad + '" y="' + y(opt.band[1]) + '" width="' + (W - pad * 2) + '" height="' + (y(opt.band[0]) - y(opt.band[1])) + '" fill="#F3E7CC"/><text x="' + (W - pad) + '" y="' + (y(opt.band[1]) - 6) + '" text-anchor="end" font-size="11" fill="#5A6577" font-family="Manrope,sans-serif">zone ' + opt.band[0] + ' à ' + opt.band[1] + '</text>' : "";
    var grid = [opt.min, (opt.min + opt.max) / 2, opt.max].map(function (v) { return '<line x1="' + pad + '" x2="' + (W - pad) + '" y1="' + y(v) + '" y2="' + y(v) + '" stroke="#E1E5EB"/><text x="' + (pad - 6) + '" y="' + (y(v) + 4) + '" text-anchor="end" font-size="10" fill="#5A6577" font-family="Manrope,sans-serif">' + Math.round(v) + '</text>'; }).join("");
    var pts = series.map(function (v, i) { return x(i) + "," + y(Math.max(opt.min, Math.min(opt.max, v))); }).join(" ");
    var dots = series.map(function (v, i) { return '<circle cx="' + x(i) + '" cy="' + y(Math.max(opt.min, Math.min(opt.max, v))) + '" r="' + (i === n - 1 ? 4.5 : 3) + '" fill="' + (i === n - 1 ? "#B5832C" : "#1D3A60") + '"/>'; }).join("");
    return '<p class="note" style="margin:6px 0 0"><b style="color:var(--ink)">' + opt.title + '</b> · ' + n + ' dernières séances</p><svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + opt.title + '">' + band + grid + '<polyline points="' + pts + '" fill="none" stroke="#1D3A60" stroke-width="2"/>' + dots + '</svg>';
  }
  function drawHist() {
    var h = hist.all();
    var wpm = h.filter(function (e) { return e.wpm; }).slice(0, 12).reverse().map(function (e) { return e.wpm; });
    var pct = h.filter(function (e) { return e.pct != null; }).slice(0, 12).reverse().map(function (e) { return e.pct; });
    $("#charts").innerHTML = chart(pct, { title: "Auto-évaluation (%)", min: 0, max: 100, empty: "Enregistrez au moins deux bilans pour voir votre courbe d'auto-évaluation." }) + chart(wpm, { title: "Débit (mots par minute)", min: 80, max: 220, band: [120, 160], empty: "Réalisez au moins deux mesures de débit pour voir votre courbe." });
    $("#hl").innerHTML = h.length ? h.slice(0, 12).map(function (e) { return '<li><span>' + new Date(e.d).toLocaleDateString("fr-FR", { day: "2-digit", month: "short" }) + '</span><span>' + esc(e.v) + '</span><span>' + esc(e.k) + '</span></li>'; }).join("") : '<li><span></span><span class="muted">Aucune séance pour l\'instant. Commencez par le diagnostic vocal.</span><span></span></li>';
  }

  draw();
})();
